const navSlide = () => {
	const burger = document.querySelector('.navbar__bars');
	const nav = document.querySelector('.navbar__menu');
	
	burger.addEventListener('click', () => {
		nav.classList.toggle('nav-active');
	});
}

navSlide();